package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class resultpage extends AppCompatActivity {
    TextView weight, height,bmi,result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultpage);
        weight = findViewById(R.id.weightshow);
        height = findViewById(R.id.heightshow);
        bmi = findViewById(R.id.bmishow);
        result = findViewById(R.id.resultshow);

        Intent intent = getIntent();

        String weightbmi=intent.getStringExtra("weightsend");
        String weightunit=intent.getStringExtra("weighttype");
        Double weightd= Double.valueOf(weightbmi.toString());
        weight.setText("Weight : "+weightd+ " "+weightunit);

        String heightbmi=intent.getStringExtra("heightsend");
        String heightunit=intent.getStringExtra("heighttype");
        Double heightd= Double.valueOf(heightbmi.toString());
        height.setText("Height : "+heightd+" "+heightunit);

            if(weightunit.equals("lb")){
                weightd=weightd*0.453592;
            }
        if(heightunit.equals("cm")){
            heightd=heightd*0.01;
        }
        if(heightunit.equals("ft")){
            heightd=heightd*0.3048;
        }
            Double bmiresult=weightd/(heightd*heightd);
            bmi.setText(String.format("BMI : %.2f ",bmiresult));

            if(bmiresult<18.5){
                result.setText("Result : UnderWeight");
            }
        if(bmiresult>=18.5 && bmiresult<=24.9){
            result.setText("Result : Normal");
        }
        if(bmiresult>=25 && bmiresult<=29.9){
            result.setText("Result : OverWeight");
        }
        if(bmiresult>=30 && bmiresult<=34.9){
            result.setText("Result : Obese");
        }
        if(bmiresult>=35 ){
            result.setText("Result : Extremly Obese");
        }
    }
}