package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    Button check;
    RadioGroup radioGroup1,radioGroup2;
    EditText weightbox,heightbox;
    String weighttype,heighttype;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        check=findViewById(R.id.checkbtn);
        weightbox=findViewById(R.id.weight);
        heightbox=findViewById(R.id.height);
        radioGroup1=findViewById(R.id.radiogrp1);
        radioGroup2=findViewById(R.id.radiogrp2);
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup1, int i) {
                switch (i){
                    case R.id.kgbtn:
                        weightbox.getText().clear();
                        weightbox.setHint("Enter your weight in kg");
                      weighttype="kg";
                        break;
                    case R.id.lbbtn:
                        weightbox.getText().clear();
                        weightbox.setHint("Enter your weight in lb");
                        weighttype="lb";
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + i);
                }
            }
        });
        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup2, int i) {
                switch (i){
                    case R.id.cmbtn:
                        heightbox.getText().clear();
                        heightbox.setHint("Enter your height in cm");
                        heighttype="cm";
                        break;
                    case R.id.mbtn:
                        heightbox.getText().clear();
                        heightbox.setHint("Enter your height in m");
                        heighttype="m";
                        break;
                    case R.id.ftbtn:
                        heightbox.getText().clear();
                        heightbox.setHint("Enter your height in ft");
                        heighttype="ft";
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + i);
                }
            }
        });


        check.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String weightsend=(weightbox.getText().toString());
                String heightsend=(heightbox.getText().toString());
                Intent intent=new Intent(getApplicationContext(),resultpage.class);
                intent.putExtra("weightsend",weightsend);
                intent.putExtra("heightsend",heightsend);
                intent.putExtra("weighttype",weighttype);
                intent.putExtra("heighttype",heighttype);
                startActivity(intent);
            }
        });
    }
}